﻿<?php
	echo "&copy;";
	echo date("Y")." | ";
	echo "Michael Hales"." | ";
	echo "CIT 230"." | ";
	echo "<a href="."http://www.byui.edu".">BYU-I</a>";
?>