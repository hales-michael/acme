<?php
	echo "<h1>Michael Hales</h1>";
	echo "<h2>PHP Assignment</h2>";
	echo "<p>".date("l"." , "."F d Y")."</p><br>";
?>